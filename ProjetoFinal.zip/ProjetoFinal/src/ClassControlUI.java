import javax.swing.*;
import java.awt.*;

public class ClassControlUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public ClassControlUI() {
        setTitle("Class Control");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Painéis do sistema
        mainPanel.add(createSophisticatedMainMenu(), "mainmenu");
        mainPanel.add(createAvisoPanel(), "avisos");
        mainPanel.add(createDisciplinaPanel(), "disciplinas");

        add(mainPanel);

        // Exibe o menu principal ao iniciar
        cardLayout.show(mainPanel, "mainmenu");
    }

    private JPanel createSophisticatedMainMenu() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.decode("#f0f4f8")); // Cor clara e moderna

        // Título no topo
        JLabel titleLabel = new JLabel("Class Control", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.decode("#2c3e50"));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); // Espaçamento
        panel.add(titleLabel, BorderLayout.NORTH);

        // Painel central para botões
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(Color.decode("#ffffff")); // Fundo branco
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); // Espaçamento entre botões
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Botão de avisos
        JButton avisoButton = createCustomButton("Avisos", "icons/notifications.png");
        avisoButton.addActionListener(e -> cardLayout.show(mainPanel, "avisos"));
        buttonPanel.add(avisoButton, gbc);

        // Botão de disciplinas
        gbc.gridx++;
        JButton disciplinaButton = createCustomButton("Disciplinas", "icons/books.png");
        disciplinaButton.addActionListener(e -> cardLayout.show(mainPanel, "disciplinas"));
        buttonPanel.add(disciplinaButton, gbc);

        panel.add(buttonPanel, BorderLayout.CENTER);

        // Rodapé com mensagem
        JLabel footerLabel = new JLabel("Gerencie seu dia com facilidade e eficiência!", SwingConstants.CENTER);
        footerLabel.setFont(new Font("Arial", Font.ITALIC, 16));
        footerLabel.setForeground(Color.decode("#7f8c8d"));
        panel.add(footerLabel, BorderLayout.SOUTH);

        return panel;
    }

    private JButton createCustomButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.decode("#3498db")); // Azul claro
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);

        // Adiciona o ícone (caso exista)
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            Image scaledIcon = icon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception ex) {
            // Caso o ícone não exista, nada será feito
        }

        // Alteração de cor ao passar o mouse
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.decode("#2980b9")); // Azul mais escuro
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.decode("#3498db")); // Retorna ao azul claro
            }
        });

        return button;
    }

    private JPanel createAvisoPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Avisos", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.decode("#2c3e50"));
        panel.add(titleLabel, BorderLayout.NORTH);

        JTextArea avisoArea = new JTextArea();
        avisoArea.setEditable(false);
        avisoArea.setFont(new Font("Arial", Font.PLAIN, 16));
        avisoArea.setLineWrap(true);
        avisoArea.setWrapStyleWord(true);

        // Exemplo de avisos fictícios
        avisoArea.setText("1. Aviso importante: Prova de matemática sexta-feira.\n\n" +
                "2. Entrega do projeto de ciências na próxima segunda-feira.");
        JScrollPane scrollPane = new JScrollPane(avisoArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton voltarButton = new JButton("Voltar");
        voltarButton.addActionListener(e -> cardLayout.show(mainPanel, "mainmenu"));
        panel.add(voltarButton, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createDisciplinaPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Disciplinas", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.decode("#2c3e50"));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel disciplinasPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        disciplinasPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        disciplinasPanel.setBackground(Color.decode("#ecf0f1"));

        // Exemplo de disciplinas fictícias
        String[][] disciplinas = {{"Matemática", "Prof. João"}, {"História", "Prof. Ana"}, {"Física", "Prof. Pedro"}};
        for (String[] disciplina : disciplinas) {
            JButton button = new JButton(disciplina[0] + " - " + disciplina[1]);
            button.setFont(new Font("Arial", Font.BOLD, 16));
            button.setBackground(Color.WHITE);
            button.setFocusPainted(false);
            button.addActionListener(e -> JOptionPane.showMessageDialog(
                    this,
                    "Disciplina: " + disciplina[0] + "\nProfessor: " + disciplina[1],
                    "Detalhes da Disciplina",
                    JOptionPane.INFORMATION_MESSAGE
            ));
            disciplinasPanel.add(button);
        }

        panel.add(disciplinasPanel, BorderLayout.CENTER);

        JButton voltarButton = new JButton("Voltar");
        voltarButton.addActionListener(e -> cardLayout.show(mainPanel, "mainmenu"));
        panel.add(voltarButton, BorderLayout.SOUTH);

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClassControlUI ui = new ClassControlUI();
            ui.setVisible(true);
        });
    }
}